
package Project1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

/**
 * 
 * @author hunte
 *
 * @version 1.0 2025-10-17 Initial implementation
 *
 *
 * @since 1.0
 */
public class Server
    {

    /**
     * 
     * @param args
     *
     * @since 1.0
     */
    public static void main( String[] args )
        {
        int port = 9876; // The port to listen on

        try (DatagramSocket serverSocket = new DatagramSocket(port)) {
            System.out.println("UDP Server started on port " + port);

            byte[] receiveData = new byte[1024];

            while (true) {
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                serverSocket.receive(receivePacket); // Blocks until a packet is received

                String message = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Received from client: " + message);

                // Echo the message back to the client
                DatagramPacket sendPacket = new DatagramPacket(receivePacket.getData(), receivePacket.getLength(),
                        receivePacket.getAddress(), receivePacket.getPort());
                serverSocket.send(sendPacket);
            }
        } catch (SocketException e) {
            System.err.println("Socket error: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("I/O error: " + e.getMessage());
        }
    }


        }

   
   // end class Server