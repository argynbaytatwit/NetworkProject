
package Project1;
import java.util.Scanner;
import java.io.IOException ;
import java.net.DatagramPacket ;
import java.net.DatagramSocket ;
import java.net.InetAddress ;
import java.net.SocketException ;
import java.net.UnknownHostException ;

/**
 * 
 * @author hunte
 *
 * @version 1.0 2025-10-17 Initial implementation
 *
 *
 * @since 1.0
 */
public class Project1
    {

    /**
     * 
     * @param args
     *
     * @since 1.0
     */
    public static void main( String[] args ) {
    String serverHostname = "169.254.231.157"; // The server's hostname or IP address
    int serverPort =9876; // The server's port

    try (DatagramSocket clientSocket = new DatagramSocket();
    Scanner scanner = new Scanner(System.in)) {

    
        InetAddress serverAddress = InetAddress.getByName(serverHostname);
        System.out.println("Connected to server at " + serverHostname + ":" + serverPort);
        System.out.println("Type message 'exit' to quit");

        
        while (true) {
        // Get message from user
        System.out.print("You: ");
        String message = scanner.nextLine();

        if (message.equalsIgnoreCase("exit")) {
            System.out.println("Exiting chat...");
            break;
        }
        
        
        byte[] sendData = message.getBytes();

        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, serverPort);
        clientSocket.send(sendPacket);
     

        byte[] receiveData = new byte[1024];

        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
        //DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length + 1);

        clientSocket.receive(receivePacket); // Blocks until a packet is received

        String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
        System.out.println("Server: " + response);
        }
    } catch (UnknownHostException e) {
        System.err.println("Unknown host: " + e.getMessage());
    } catch (SocketException e) {
        System.err.println("Socket error: " + e.getMessage());
    } catch (IOException e) {
        System.err.println("I/O error: " + e.getMessage());
    } 
    /*catch (IllegalArgumentException e) {
        System.err.println("Parameter error: " + e.getMessage());
    }*/
}
}
   // end class Project1